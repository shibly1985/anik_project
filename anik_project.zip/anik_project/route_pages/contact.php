<?php
$getData = "SELECT * FROM content WHERE parent_menu='" . $_GET['route'] . "'";
$excQry = mysqli_query($con, $getData);
$row = mysqli_fetch_array($excQry);
?>
<div class="content">
    <div class="project-section wow bounceIn animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
        <div class="container">
            <h3>Contact</h3>
            <div class="about-grids">                       
                <div class="col-md-12 about-grid wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <div class="contact-map wow bounceIn animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1578265.0941403757!2d-98.9828708842255!3d39.41170802696131!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sin!4v1407515822047"> </iframe>
						</div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>