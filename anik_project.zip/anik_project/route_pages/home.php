
<div class="content">
    <div class="about-section">
        <div class="container">
        <?php
		
		if(isset($_POST['submit'])){
		$name = mysqli_real_escape_string($con, $_POST['name']);
		$mobile_no = mysqli_real_escape_string($con, $_POST['mobile_no']);
		$nid_or_dob_no = mysqli_real_escape_string($con, $_POST['nid_or_dob_no']);
		$village = mysqli_real_escape_string($con, $_POST['village']);
		$upozila = mysqli_real_escape_string($con, $_POST['upozila']);
		$district = mysqli_real_escape_string($con, $_POST['district']);
		
		$sql="INSERT INTO farmer_info (name, mobile_no, nid_or_dob_no,village, upozila, district)
		VALUES ('$name', '$mobile_no', '$nid_or_dob_no','$village', '$upozila', '$district')";
		
		if (!mysqli_query($con,$sql)) {
		  die('Error: ' . mysqli_error($con));
			}
			else{
				header('Location: index.php?route=success');
			}
		}
		
		?>
            <h3>কৃষকের অংশগ্রহণ</h3>
            <div class="about-grids">
                <form id="form1" name="form1" method="post" action="">
                    <div class="row">
                        <!-- start code on the left side of the page -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> নাম</label>
                                <div class="col-sm-6 ">
                                    <input type="text" class="form-control" name="name" id="name" placeholder= "নাম" 
                                           ondrop="return false;" onpaste="return false;" /></span>
                                </div>
                            </div>
                            <!-- Use clearfix here -->
                            <div class="clearfix"></div><br/>
                            <div class="form-group">
                                <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> মোবাইল নম্বর</label>
                                <div class="col-sm-6 ">
                                    <input type="number" class="form-control" name="mobile_no" id="mobile_no" placeholder= "মোবাইল নম্বর" 
                                           ondrop="return false;" onpaste="return false;" /></span>
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="form-group">
                                <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> ন্যাশনাল আইডি/জন্মনিবন্ধন নম্বর</label>
                                <div class="col-sm-6 ">
                                    <input type="text" class="form-control" name="nid_or_dob_no" id="nid_or_dob_no" placeholder= "ন্যাশনাল আইডি/জন্মনিবন্ধন নম্বর" 
                                           ondrop="return false;" onpaste="return false;" /></span>
                                </div>
                            </div>

                        </div>
                        <!-- left code ends here -->

                        <!-- start code on the right side of the page -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-sm-3 control-label"><font color="red"><b>*</b></font>গ্রাম</label>
                                <div class="col-sm-6 ">
                                    <input type="text" class="form-control" name="village" id="village" placeholder= "গ্রাম" 
                                           ondrop="return false;" onpaste="return false;" /></span>
                                </div>
                            </div>
                            <!-- Use clearfix here -->
                            <div class="clearfix"></div><br/>
                            <div class="form-group">
                                <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> উপজেলা</label>
                                <div class="col-sm-6 ">
                                    <input type="text" class="form-control" name="upozila" id="upozila" placeholder= "উপজেলা" 
                                           ondrop="return false;" onpaste="return false;" /></span>
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="form-group">
                                <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> জেলা</label>
                                <div class="col-sm-6 ">
                                    <input type="text" class="form-control" name="district" id="district" placeholder= "জেলা" 
                                           ondrop="return false;" onpaste="return false;" /></span>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div><br/>
                        <div class="row" style="margin-left:80px; margin-top:40px;">
                            <button type="submit" name="submit" class="btn btn-success">সংরক্ষন করুন</button>
                        </div>

                        <!-- right code ends here -->
                    </div>
                </form>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <div class="news-section">
        <!--<div class="service-section">-->
        <div class="container">
            <h3>কৃষকের সেবাসমুহ</h3>
            <div class="service-grids">
                <div class="col-md-4 service-grid wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <a href="?route=time-crops">
                        <img src="images/site_img/Seba_1.png" class="img-responsive" alt="/" height="150px" width="150px">                                                   
                        <p>সময় এবং ফসল</p>
                    </a>
                </div>
                <div class="col-md-4 service-grid wow fadeInUpBig animated animated" data-wow-delay="0.4s">
                    <a href="?route=modern-technology-of-crop-plough">
                        <img src="images/site_img/Seba_2.png" class="img-responsive" alt="/" height="150px" width="150px">    
                        <p>ফসল চাষের আধুনিক পদ্ধতি</p>
                    </a>
                </div>
                <div class="col-md-4 service-grid wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <a href="?route=crop-deseases-and-solutions">
                        <img src="images/site_img/Seba_3.png" class="img-responsive" alt="/" height="150px" width="150px">    
                        <p>ফসলের বালাই এবং সমাধান</p>
                    </a>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-4 service-grid wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <a href="?route=gov-help">
                        <img src="images/site_img/Seba_4.png" class="img-responsive" alt="/" height="150px" width="150px">    
                        <p>সরকারি সহযোগিতা</p>
                    </a>
                </div>
                <div class="col-md-4 service-grid wow fadeInUpBig animated animated" data-wow-delay="0.4s">
                    <a href="?route=non-gov-help">
                        <img src="images/site_img/Seba_5.png" class="img-responsive" alt="/" height="150px" width="150px">    
                        <p>বেসরকারি সহযোগিতা</p>
                    </a>
                </div>
                <div class="col-md-4 service-grid wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <a href="?route=digital-system-of-crop-marketing">
                        <img src="images/site_img/Seba_6.png" class="img-responsive" alt="/" height="150px" width="150px">    
                        <p>ফসল বাজারজাতকরনের ডিজিটাল পদ্ধতি</p>
                    </a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>


</div>


