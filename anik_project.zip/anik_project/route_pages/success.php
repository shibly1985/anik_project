<div class="content">
    <div class="project-section wow bounceIn animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
        <div class="container well">
            আপনার তথ্য সংরক্ষণ করা হয়েছে। ধন্যবাদ।
        </div>
    </div>
</div>