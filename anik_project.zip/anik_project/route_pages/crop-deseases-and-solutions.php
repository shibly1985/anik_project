<?php
$getData = "SELECT * FROM content WHERE parent_menu='" . $_GET['route'] . "'";
$excQry = mysqli_query($con, $getData);
$row = mysqli_fetch_array($excQry);
?>
<div class="content">
    <div class="project-section wow bounceIn animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
        <div class="container">
            <h3><?php echo $row['title']; ?></h3>
            <div class="about-grids">                       
                <div class="col-md-12 about-grid wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <?php
                    echo $row['content'];
                    ?>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>