<?php

    if ($_GET['route'] == 'home' OR $_GET['route'] == '') {
        $id = 'header';
    } else {
        $id = 'header head-top';
    }

?>
<body>
    <div class="<?php echo $id; ?>" id="home">
        <div class="container">
            <div class="header-top">
                <div class="top-menu">
                    <span class="menu"><img src="images/nav.png" alt=""/> </span>
                    <ul>
                        <li><a href="?route=home" class="active">মেইন</a></li><label>|</label>
                        <!--<li><a href="about.html">সময় এবং ফসল</a></li><label>|</label>-->
                        <!--<li><a href="services.html">ফসল চাষের আধুনিক পদ্ধতি</a></li><label>|</label>-->
                        <!--<li><a href="products.html">ফসলের বালাই এবং সমাধান</a></li><label>|</label>-->
                        <li><a href="?route=gov-help">সরকারি সহযোগিতা</a></li><label>|</label>
                        <li><a href="?route=non-gov-help">বেসরকারি সহযোগিতা</a></li><label>|</label>
                        <!--<li><a href="contact.html">ফসল বাজারজাতকরনের সরকারি পদ্ধতি।</a></li><label>|</label>-->
                        <li  class="dropdown"><a href="#">ফসল </a>
                            <ul class="dropdown-menu">
                                <li><a href="?route=time-crops">সময় এবং ফসল</a></li>
                                <li><a href="?route=modern-technology-of-crop-plough">ফসল চাষের আধুনিক পদ্ধতি</a></li>
                                <li><a href="?route=crop-deseases-and-solutions">ফসলের বালাই এবং সমাধান</a></li>
                                <li><a href="?route=gov-policy-of-crop-marketing">ফসল বাজারজাতকরনের ডিজিটাল পদ্ধতি</a></li>
                            </ul>
                        </li><label>|</label>

                        <li><a href="?route=contact">যোগাযোগ</a></li>

                    </ul>
                    <!-- script for menu -->

                    <script>
                        $("span.menu").click(function () {
                            $(".top-menu ul").slideToggle("slow", function () {
                            });
                        });
                    </script>
                    <!-- //script for menu -->
                </div>
                <div class="search">
                    +8801707121121
                </div>

                <div class="clearfix"></div>

            </div>
            <div class="logo wow bounceIn animated" data-wow-delay="0.4s" >
                <!--<img src="images/Logo_01.png"" class="img-responsive" alt="/">-->
               <h1> কৃষকের অনলাইন বন্ধু </h1>
            </div>




            	<?php
         
                if ($_GET['route'] == 'home' OR $_GET['route'] == '') {
				
				$getCardInfo_1="SELECT title,short_description FROM `home_card` WHERE flag=1";							
				$excQry_1=mysqli_query($con,$getCardInfo_1);
				$row_1=mysqli_fetch_array($excQry_1);
				
				$getCardInfo_2="SELECT title,short_description FROM `home_card` WHERE flag=2";							
				$excQry_2=mysqli_query($con,$getCardInfo_2);
				$row_2=mysqli_fetch_array($excQry_2);
				
				$getCardInfo_3="SELECT title,short_description FROM `home_card` WHERE flag=3";							
				$excQry_1=mysqli_query($con,$getCardInfo_3);
				$row_3=mysqli_fetch_array($excQry_3);
				
				$getCardInfo_4="SELECT title,short_description FROM `home_card` WHERE flag=4";							
				$excQry_4=mysqli_query($con,$getCardInfo_4);
				$row_4=mysqli_fetch_array($excQry_4);
                    ?>

                    <!-- Only Home Content -->
                    <div class="header-bottom">
                        <div class="header-grids">
                            <div class="col-md-3 header-grid">
                                <div class="header-img1 wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s; height:350px; width:250px;">
                                    <img src="images/icon4.png"" class="img-responsive" alt="/">
                                    <h4><?php echo $row_1['title']; ?></h4>
                                    <p><?php echo $row_1['short_description']; ?></p>
                                </div>
                            </div>
                            <div class="col-md-3 header-grid">
                                <div class="header-img2 wow fadeInDownBig animated animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s; height:350px; width:250px;">
                                    <img src="images/icon5.png"" class="img-responsive" alt="/">
                                    <h4><?php echo $row_2['title']; ?></h4>
                                    <p><?php echo $row_2['short_description']; ?></p>
                                </div>
                            </div>

                            <div class="col-md-3 header-grid">
                                <div class="header-img3 wow fadeInUpBig animated animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s; height:350px; width:250px;">
                                    <img src="images/icon6.png"" class="img-responsive" alt="/">
                                    <h4><?php echo $row_3['title']; ?></h4>
                                    <p><?php echo $row_3['short_description']; ?></p>
                                </div>
                            </div>
                            <div class="col-md-3 header-grid">
                                <div class="header-img4 wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s; height:350px; width:250px;">
                                    <img src="images/icon7.png"" class="img-responsive" alt="/">
                                    <h4><?php echo $row_4['title']; ?></h4>
                                    <p><?php echo $row_4['short_description']; ?></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>	
                    <!-- Home Content End -->

                <?php 
            }
            ?>
        </div>
    </div>

