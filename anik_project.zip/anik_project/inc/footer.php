<div class="footer-section">
            <div class="container">
                <div class="footer-top">
                    <div class="social-icons wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                        <a href="#"><i class="icon1"></i></a>
                        <a href="#"><i class="icon2"></i></a>
                        <a href="#"><i class="icon3"></i></a>
                        <a href="#"><i class="icon4"></i></a>
                    </div>
                </div>
                <div class="footer-middle wow fadeInDown Big animated animated" data-wow-delay="0.4s">
                    <div class="bottom-menu">
                        <ul>
                            <!--<li><a href="?route=home">মেইন</a></li>-->
                            <li><a href="?route=time-crops">সময় এবং ফসল</a></li>
                            <li><a href="?route=modern-technology-of-crop-plough">ফসল চাষের আধুনিক পদ্ধতি</a></li>
                            <li><a href="?route=crop-deseases-and-solutions">ফসলের বালাই এবং সমাধান</a></li>
                            <li><a href="?route=digital-system-of-crop-marketing">ফসল বাজারজাতকরনের ডিজিটাল পদ্ধতি</a></li>-
                            <!--<li><a href="contact.html">বেসরকারি সহযোগিতা</a></li>-->
							<!--<li><a href="blog.html">ফসল বাজারজাতকরনের সরকারি পদ্ধতি</a></li>-->
                            <!--<li><a href="contact.html">যোগাযোগ</a></li>-->
                        </ul>
                    </div>
                </div>
                <div class="footer-bottom wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <p> কৃষকের অনলাইন বন্ধু ওয়েবসত্ব-২০১৯ </p>
                </div>
                <script type="text/javascript">
                    $(document).ready(function () {
                        /*
                         var defaults = {
                         containerID: 'toTop', // fading element id
                         containerHoverID: 'toTopHover', // fading element hover id
                         scrollSpeed: 1200,
                         easingType: 'linear' 
                         };
                         */

                        $().UItoTop({easingType: 'easeOutQuart'});

                    });
                </script>
                <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
            </div>
        </div>

    </body>
</html> 