<?php


if (!isset($_GET['route'])) {
    include("route_pages/home.php");
} else {
    include("route_pages/" . $_GET['route'] . ".php");
}
?>