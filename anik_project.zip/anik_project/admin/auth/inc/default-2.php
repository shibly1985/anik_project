<div id="page-wrapper">
            
            <!-- /.row -->
            <form id=""  method="post" action="" >
            <div class="row">
            
            <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Pie Chart Example
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                          
                          <div class="col-lg-6">
                          	<div class="form-group">
                            	<label>Name</label>
                            	<input type="text" name="name" id="name" class="form-control" required>
                        	</div>
                          </div>
                          
                          <div class="col-lg-6">
                          <div class="form-group">
                            	<label>Name</label>
                            	<input type="text" name="name" id="name" class="form-control" required>
                        	</div>
                          </div>
                          
                          
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
                <!-- /.col-lg-12 -->
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add SkillSets
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="form-group">
                            <label for="przychody" class="col-sm-6 control-label"><?php echo "Test1"; ?>:</label>
                            <div class="col-sm-6">
                                <select class="form-control select2"  name="core_UniversityEngScience">
                                    <option selected="selected" value="yes">Yes</option>
                                    <option value="no">No</option>                               
                                </select>   
                            </div>
                        </div>
                        <br/><br/>

                        <div class="form-group">
                            <label for="przychody" class="col-sm-6 control-label"><?php echo "Test1"; ?>:</label>
                           <div class="col-sm-6">
                                <!--<select class="form-control select2"  name="core_CommercialPilot">
                                    <option selected="selected" value="yes">Yes</option>
                                    <option value="no">No</option>                               
                                </select>-->
                                
                                <input type="text" name="core_CommercialPilot" id="core_CommercialPilot" class="form-control"  >   
                            </div>
                            
                           
                            
                            
                        </div>
                        <br/><br/>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add SkillSets
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="flot-chart">
                                <div class="flot-chart-content" id="flot-line-chart-multi"></div>
                            </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>                
            </div>
            </form>    
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->