
<!DOCTYPE HTML>
<html>
    <head>
        <title>Cultivation a Agriculture  Category Flat Bootstarp Resposive Website Template | Home :: w3layouts</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Cultivation Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Josefin+Sans:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic' rel='stylesheet' type='text/css'>
        <script src="js/jquery-1.11.1.min.js"></script>
        <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
        <!---- start-smoth-scrolling---->
        <script type="text/javascript" src="js/move-top.js"></script>
        <script type="text/javascript" src="js/easing.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $(".scroll").click(function (event) {
                    event.preventDefault();
                    $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1200);
                });
            });
        </script>
        <!---End-smoth-scrolling---->
        <link rel="stylesheet" href="css/swipebox.css">
        <script src="js/jquery.swipebox.min.js"></script> 
        <script type="text/javascript">
            jQuery(function ($) {
                $(".swipebox").swipebox();
            });
        </script>
        <!--Animation-->
        <script src="js/wow.min.js"></script>
        <link href="css/animate.css" rel='stylesheet' type='text/css' />
        <script>
            new WOW().init();
        </script>
        <!---/End-Animation---->

        <style>
            .dropdown:hover .dropdown-menu {
                display: block; 
                background:#8f8774;
                margin: 2px -15px 0 !important;
            }
            .search {
                float: right;
                position: relative;
                width: 20%;
                border: 0px solid #ededed !important; 
                margin: 0.85em 1em;
            }
        </style>
    </head>
    <body>
        <div class="header" id="home">
            <div class="container">
                <div class="header-top">
                    <div class="top-menu">
                        <span class="menu"><img src="images/nav.png" alt=""/> </span>
                        <ul>
                            <li><a href="index.html" class="active">মেইন</a></li><label>|</label>
                            <!--<li><a href="about.html">সময় এবং ফসল</a></li><label>|</label>-->
                            <!--<li><a href="services.html">ফসল চাষের আধুনিক পদ্ধতি</a></li><label>|</label>-->
                            <!--<li><a href="products.html">ফসলের বালাই এবং সমাধান</a></li><label>|</label>-->
                            <li><a href="blog.html">সরকারি সহযোগিতা</a></li><label>|</label>
                            <li><a href="contact.html">বেসরকারি সহযোগিতা</a></li><label>|</label>
                            <!--<li><a href="contact.html">ফসল বাজারজাতকরনের সরকারি পদ্ধতি।</a></li><label>|</label>-->
                            <li  class="dropdown"><a href="#">ফসল </a>
                                <ul class="dropdown-menu">
                                    <li><a href="about.html">সময় এবং ফসল</a></li>
                                    <li><a href="services.html">ফসল চাষের আধুনিক পদ্ধতি</a></li>
                                    <li><a href="products.html">ফসলের বালাই এবং সমাধান</a></li>
                                    <li><a href="contact.html">ফসল বাজারজাতকরনের সরকারি পদ্ধতি।</a></li>
                                </ul>
                            </li><label>|</label>

                            <li><a href="index.html">যোগাযোগ</a></li>

                        </ul>
                        <!-- script for menu -->

                        <script>
                            $("span.menu").click(function () {
                                $(".top-menu ul").slideToggle("slow", function () {
                                });
                            });
                        </script>
                        <!-- //script for menu -->
                    </div>
                    <div class="search">
                        +8801707121121
                    </div>

                    <div class="clearfix"></div>

                </div>
                <div class="logo wow bounceIn animated" data-wow-delay="0.4s" >
                    <img src="images/Logo_01.png"" class="img-responsive" alt="/">
                </div>
                <div class="header-bottom">
                    <div class="header-grids">
                        <div class="col-md-3 header-grid">
                            <div class="header-img1 wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                                <img src="images/icon4.png"" class="img-responsive" alt="/">
                                <h4>সময় এবং ফসল </h4>
                                <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.</p>
                            </div>
                        </div>
                        <div class="col-md-3 header-grid">
                            <div class="header-img2 wow fadeInDownBig animated animated" data-wow-delay="0.4s">
                                <img src="images/icon5.png"" class="img-responsive" alt="/">
                                <h4>সময় এবং ফসল</h4>
                                <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.</p>
                            </div>
                        </div>

                        <div class="col-md-3 header-grid">
                            <div class="header-img3 wow fadeInUpBig animated animated" data-wow-delay="0.4s">
                                <img src="images/icon6.png"" class="img-responsive" alt="/">
                                <h4>সময় এবং ফসল</h4>
                                <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.</p>
                            </div>
                        </div>
                        <div class="col-md-3 header-grid">
                            <div class="header-img4 wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                                <img src="images/icon7.png"" class="img-responsive" alt="/">
                                <h4>সময় এবং ফসল</h4>
                                <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.</p>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>	
            </div>
        </div>
        <div class="content">
            <div class="about-section">
                <div class="container">
                    <h3>কৃষকের অংশগ্রহণ</h3>
                    <div class="about-grids">
                        <div class="row">
                            <!-- start code on the left side of the page -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> E-mail</label>
                                    <div class="col-sm-6 ">
                                        <input type="text" class="form-control" name="email" id="email" placeholder= "email" 
                                               ondrop="return false;" onpaste="return false;" /></span>
                                    </div>
                                </div>
                                <!-- Use clearfix here -->
                                <div class="clearfix"></div><br/>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> Username</label>
                                    <div class="col-sm-6 ">
                                        <input type="text" class="form-control" name="username" id="username" placeholder= "username" 
                                               ondrop="return false;" onpaste="return false;" /></span>
                                    </div>
                                </div>
                                <div class="clearfix"></div><br/>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> Username</label>
                                    <div class="col-sm-6 ">
                                        <input type="text" class="form-control" name="username" id="username" placeholder= "username" 
                                               ondrop="return false;" onpaste="return false;" /></span>
                                    </div>
                                </div>

                            </div>
                            <!-- left code ends here -->

                            <!-- start code on the right side of the page -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> E-mail</label>
                                    <div class="col-sm-6 ">
                                        <input type="text" class="form-control" name="email" id="email" placeholder= "email" 
                                               ondrop="return false;" onpaste="return false;" /></span>
                                    </div>
                                </div>
                                <!-- Use clearfix here -->
                                <div class="clearfix"></div><br/>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> Username</label>
                                    <div class="col-sm-6 ">
                                        <input type="text" class="form-control" name="username" id="username" placeholder= "username" 
                                               ondrop="return false;" onpaste="return false;" /></span>
                                    </div>
                                </div>
                                <div class="clearfix"></div><br/>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><font color="red"><b>*</b></font> Username</label>
                                    <div class="col-sm-6 ">
                                        <input type="text" class="form-control" name="username" id="username" placeholder= "username" 
                                               ondrop="return false;" onpaste="return false;" /></span>
                                    </div>
                                </div>
                            </div>
                            <!-- right code ends here -->
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="news-section">
                <!--<div class="service-section">-->
                <div class="container">
                    <h3>কৃষকের সেবাসমুহ</h3>
                    <div class="service-grids">
                        <div class="col-md-4 service-grid wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                            <img src="images/icon1.png" class="img-responsive" alt="/">
                            <h4>Dolor nunc vule putateulr</h4>
                            <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.Praesent nec sagittis mauris. Fusce convallis nunc neque.Integer egestas.Vivamus laoreet velit justo</p>
                        </div>
                        <div class="col-md-4 service-grid wow fadeInUpBig animated animated" data-wow-delay="0.4s">
                            <img src="images/icon2.png" class="img-responsive" alt="/">
                            <h4>Dolor nunc vule putateulr</h4>
                            <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.Praesent nec sagittis mauris. Fusce convallis nunc neque.Integer egestas.Vivamus laoreet velit justo</p>
                        </div>
                        <div class="col-md-4 service-grid wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                            <img src="images/icon3.png" class="img-responsive" alt="/">
                            <h4>Dolor nunc vule putateulr</h4>
                            <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.Praesent nec sagittis mauris. Fusce convallis nunc neque.Integer egestas.Vivamus laoreet velit justo</p>
                            `					</div>
                        <div class="clearfix"></div>
                        <div class="col-md-4 service-grid wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                            <img src="images/icon1.png" class="img-responsive" alt="/">
                            <h4>Dolor nunc vule putateulr</h4>
                            <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.Praesent nec sagittis mauris. Fusce convallis nunc neque.Integer egestas.Vivamus laoreet velit justo</p>
                        </div>
                        <div class="col-md-4 service-grid wow fadeInUpBig animated animated" data-wow-delay="0.4s">
                            <img src="images/icon2.png" class="img-responsive" alt="/">
                            <h4>Dolor nunc vule putateulr</h4>
                            <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.Praesent nec sagittis mauris. Fusce convallis nunc neque.Integer egestas.Vivamus laoreet velit justo</p>
                        </div>
                        <div class="col-md-4 service-grid wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                            <img src="images/icon3.png" class="img-responsive" alt="/">
                            <h4>Dolor nunc vule putateulr</h4>
                            <p>Cras consequat iaculis lorem, id vehicula erat mattis quis. Vivamus laoreet velit justo, in ven e natis purus.Praesent nec sagittis mauris. Fusce convallis nunc neque.Integer egestas.Vivamus laoreet velit justo</p>
                            `					</div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>


        </div>

        <div class="footer-section">
            <div class="container">
                <div class="footer-top">
                    <div class="social-icons wow bounceInLeft animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                        <a href="#"><i class="icon1"></i></a>
                        <a href="#"><i class="icon2"></i></a>
                        <a href="#"><i class="icon3"></i></a>
                        <a href="#"><i class="icon4"></i></a>
                    </div>
                </div>
                <div class="footer-middle wow fadeInDown Big animated animated" data-wow-delay="0.4s">
                    <div class="bottom-menu">
                        <ul>
                            <li><a href="index.html">home</a></li>
                            <li><a href="about.html">About</a></li>
                            <li><a href="services.html">Services</a></li>
                            <li><a href="products.html">products</a></li>
                            <li><a href="blog.html">blog</a></li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="footer-bottom wow bounceInRight animated" data-wow-delay="0.4s" style="visibility: visible; -webkit-animation-delay: 0.4s;">
                    <p> Copyright &copy;2015  All rights  Reserved </p>
                </div>
                <script type="text/javascript">
                    $(document).ready(function () {
                        /*
                         var defaults = {
                         containerID: 'toTop', // fading element id
                         containerHoverID: 'toTopHover', // fading element hover id
                         scrollSpeed: 1200,
                         easingType: 'linear' 
                         };
                         */

                        $().UItoTop({easingType: 'easeOutQuart'});

                    });
                </script>
                <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
            </div>
        </div>

    </body>
</html> 